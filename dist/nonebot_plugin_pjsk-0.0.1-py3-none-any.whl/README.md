<div align="center">
  <img src="https://raw.githubusercontent.com/Agnes4m/nonebot_plugin_l4d2_server/main/image/logo.png" width="180" height="180"  alt="AgnesDigitalLogo">
  <br>
  <p><img src="https://s2.loli.net/2022/06/16/xsVUGRrkbn1ljTD.png" width="240" alt="NoneBotPluginText"></p>
</div>

<div align="center">

# nonebot_plugin_friends

__✨PJSK表情包制作✨__

<a href="https://github.com/Agnes4m/nonebot_plugin_pjsk/stargazers">
        <img alt="GitHub stars" src="https://img.shields.io/github/stars/Agnes4m/nonebot_plugin_pjsk" alt="stars">
</a>
<a href="https://github.com/Agnes4m/nonebot_plugin_pjsk/issues">
        <img alt="GitHub issues" src="https://img.shields.io/github/issues/Agnes4m/nonebot_plugin_pjsk" alt="issues">
</a>
<a href="https://jq.qq.com/?_wv=1027&k=l82tMuPG">
        <img src="https://img.shields.io/badge/QQ%E7%BE%A4-424506063-orange?style=flat-square" alt="QQ Chat Group">
</a>
<a href="https://pypi.python.org/pypi/nonebot_plugin_pjsk">
        <img src="https://img.shields.io/pypi/v/nonebot_plugin_pjsk.svg" alt="pypi">
</a>
    <img src="https://img.shields.io/badge/python-3.8+-blue.svg" alt="python">
    <img src="https://img.shields.io/badge/nonebot-2.0.0-red.svg" alt="NoneBot">
</div>

## 效果

<img src="https://raw.githubusercontent.com/Agnes4m/nonebot_plugin_pjsk/main/test.png" width="512" height="512"  alt="pjsk_test">

## 资源包

在release下载，并放入data/pjsk中

## 指令

- pjsk 【text】

## 🙈 其他

- 本项目仅供学习使用，请勿用于商业用途，喜欢该项目可以Star或者提供PR
- [爱发电](https://afdian.net/a/agnes_digital)

